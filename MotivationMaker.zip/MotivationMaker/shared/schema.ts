import { pgTable, text, serial, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Quote table
export const quotes = pgTable("quotes", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  author: text("author").notNull(),
  category: text("category"),
});

export const insertQuoteSchema = createInsertSchema(quotes).pick({
  text: true,
  author: true,
  category: true,
});

// Background images table
export const backgrounds = pgTable("backgrounds", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  description: text("description"),
  type: text("type").notNull(), // landscape, nature, abstract
});

export const insertBackgroundSchema = createInsertSchema(backgrounds).pick({
  url: true,
  description: true,
  type: true,
});

// Generated quote images table
export const generatedImages = pgTable("generated_images", {
  id: serial("id").primaryKey(),
  quoteId: serial("quote_id").notNull(),
  backgroundId: serial("background_id").notNull(),
  fontStyle: text("font_style").notNull(), // elegant, modern, classic
  textColor: text("text_color").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertGeneratedImageSchema = createInsertSchema(generatedImages).pick({
  quoteId: true,
  backgroundId: true,
  fontStyle: true,
  textColor: true,
  imageUrl: true,
});

// Post scheduling table
export const scheduledPosts = pgTable("scheduled_posts", {
  id: serial("id").primaryKey(),
  imageId: serial("image_id").notNull(),
  platform: text("platform").notNull(), // instagram, pinterest, twitter
  caption: text("caption").notNull(),
  affiliateLink: text("affiliate_link"),
  scheduleDate: timestamp("schedule_date").notNull(),
  status: text("status").notNull().default("pending"), // pending, posted, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertScheduledPostSchema = createInsertSchema(scheduledPosts).pick({
  imageId: true,
  platform: true,
  caption: true,
  affiliateLink: true,
  scheduleDate: true,
});

// Types
export type Quote = typeof quotes.$inferSelect;
export type InsertQuote = z.infer<typeof insertQuoteSchema>;

export type Background = typeof backgrounds.$inferSelect;
export type InsertBackground = z.infer<typeof insertBackgroundSchema>;

export type GeneratedImage = typeof generatedImages.$inferSelect;
export type InsertGeneratedImage = z.infer<typeof insertGeneratedImageSchema>;

export type ScheduledPost = typeof scheduledPosts.$inferSelect;
export type InsertScheduledPost = z.infer<typeof insertScheduledPostSchema>;
