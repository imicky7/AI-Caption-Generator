// Social Media API Integration
import fetch from 'node-fetch';
import FormData from 'form-data';

// Interface for post data
interface PostData {
  caption: string;
  imageUrl: string;
  platform: 'instagram' | 'twitter' | 'pinterest';
  affiliateLink?: string;
}

// Social Media Posting Service
class SocialMediaService {
  // Instagram API Integration
  async postToInstagram(postData: PostData): Promise<{ success: boolean; message: string; postId?: string }> {
    try {
      if (!process.env.INSTAGRAM_ACCESS_TOKEN) {
        return { 
          success: false, 
          message: "Instagram access token not found in environment variables" 
        };
      }
      
      const accessToken = process.env.INSTAGRAM_ACCESS_TOKEN;
      
      // Step 1: Upload the image to get a media container ID
      const formData = new FormData();
      formData.append('image_url', postData.imageUrl);
      formData.append('caption', postData.caption);
      formData.append('access_token', accessToken);
      
      const response = await fetch(
        `https://graph.facebook.com/v18.0/me/media?access_token=${accessToken}`, 
        {
          method: 'POST',
          body: formData
        }
      );
      
      const data = await response.json() as any;
      
      if (!response.ok) {
        return {
          success: false,
          message: `Instagram API error: ${data.error?.message || 'Unknown error'}`
        };
      }
      
      // Step 2: Publish the container
      const publishResponse = await fetch(
        `https://graph.facebook.com/v18.0/me/media_publish?access_token=${accessToken}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ creation_id: data.id })
        }
      );
      
      const publishData = await publishResponse.json() as any;
      
      if (!publishResponse.ok) {
        return {
          success: false,
          message: `Instagram API publishing error: ${publishData.error?.message || 'Unknown error'}`
        };
      }
      
      return {
        success: true,
        message: "Successfully posted to Instagram",
        postId: publishData.id
      };
      
    } catch (error) {
      console.error("Instagram posting error:", error);
      return {
        success: false,
        message: `Error posting to Instagram: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
  
  // Twitter API Integration
  async postToTwitter(postData: PostData): Promise<{ success: boolean; message: string; postId?: string }> {
    try {
      if (!process.env.TWITTER_API_KEY || !process.env.TWITTER_API_SECRET) {
        return { 
          success: false, 
          message: "Twitter API credentials not found in environment variables" 
        };
      }
      
      // Note: Twitter v2 API requires OAuth 2.0 app-only authentication
      // For simplicity, we're showing the basic structure of the integration
      
      // 1. Get bearer token
      const credentials = Buffer.from(`${process.env.TWITTER_API_KEY}:${process.env.TWITTER_API_SECRET}`).toString('base64');
      
      const tokenResponse = await fetch('https://api.twitter.com/oauth2/token', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${credentials}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'grant_type=client_credentials'
      });
      
      const tokenData = await tokenResponse.json() as any;
      
      if (!tokenResponse.ok) {
        return {
          success: false,
          message: `Twitter API authentication error: ${JSON.stringify(tokenData)}`
        };
      }
      
      const bearerToken = tokenData.access_token;
      
      // 2. Upload media
      const mediaFormData = new FormData();
      mediaFormData.append('media', postData.imageUrl);
      
      const mediaResponse = await fetch('https://upload.twitter.com/1.1/media/upload.json', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${bearerToken}`
        },
        body: mediaFormData
      });
      
      const mediaData = await mediaResponse.json() as any;
      
      if (!mediaResponse.ok) {
        return {
          success: false,
          message: `Twitter media upload error: ${JSON.stringify(mediaData)}`
        };
      }
      
      // 3. Create tweet with media
      const tweetResponse = await fetch('https://api.twitter.com/2/tweets', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${bearerToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: postData.caption,
          media: {
            media_ids: [mediaData.media_id_string]
          }
        })
      });
      
      const tweetData = await tweetResponse.json() as any;
      
      if (!tweetResponse.ok) {
        return {
          success: false,
          message: `Twitter post creation error: ${JSON.stringify(tweetData)}`
        };
      }
      
      return {
        success: true,
        message: "Successfully posted to Twitter",
        postId: tweetData.data.id
      };
      
    } catch (error) {
      console.error("Twitter posting error:", error);
      return {
        success: false,
        message: `Error posting to Twitter: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
  
  // Pinterest API Integration
  async postToPinterest(postData: PostData): Promise<{ success: boolean; message: string; postId?: string }> {
    // Pinterest API integration would follow a similar pattern
    // This is a placeholder for the implementation
    return {
      success: false,
      message: "Pinterest API integration not implemented yet"
    };
  }
  
  // General method for posting to any platform
  async postToSocialMedia(postData: PostData): Promise<{ success: boolean; message: string; postId?: string }> {
    switch (postData.platform) {
      case 'instagram':
        return this.postToInstagram(postData);
      case 'twitter':
        return this.postToTwitter(postData);
      case 'pinterest':
        return this.postToPinterest(postData);
      default:
        return {
          success: false,
          message: `Unsupported platform: ${postData.platform}`
        };
    }
  }
}

export const socialMedia = new SocialMediaService();