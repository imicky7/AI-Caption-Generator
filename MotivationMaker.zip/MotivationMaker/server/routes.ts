import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { backgroundImages } from "@/lib/backgroundData";
import fs from 'fs';
import path from 'path';
import { quotes } from "./imageGenerator";
import { socialMedia } from './socialMedia';

// Popular inspirational quotes for initial data
const defaultQuotes = [
  { text: "The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle.", author: "Steve Jobs" },
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon" },
  { text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt" },
  { text: "Success is not final, failure is not fatal: It is the courage to continue that counts.", author: "Winston Churchill" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
  { text: "Your time is limited, so don't waste it living someone else's life.", author: "Steve Jobs" },
  { text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair" },
  { text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky" }
];

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize storage with some quotes
  for (const quote of defaultQuotes) {
    await storage.addQuote({ text: quote.text, author: quote.author, category: "inspirational" });
  }
  
  // Initialize backgrounds
  for (const type in backgroundImages) {
    const typeBackgrounds = backgroundImages[type as keyof typeof backgroundImages];
    for (const bg of typeBackgrounds) {
      await storage.addBackground({
        url: bg.url,
        description: bg.description,
        type: type
      });
    }
  }

  // API routes
  app.get('/api/quotes/random', async (req, res) => {
    try {
      const randomQuote = await storage.getRandomQuote();
      res.json(randomQuote);
    } catch (error) {
      console.error('Error getting random quote:', error);
      res.status(500).json({ error: 'Failed to get random quote' });
    }
  });

  app.get('/api/backgrounds/:type', async (req, res) => {
    try {
      const { type } = req.params;
      const backgrounds = await storage.getBackgroundsByType(type);
      res.json(backgrounds);
    } catch (error) {
      console.error('Error getting backgrounds:', error);
      res.status(500).json({ error: 'Failed to get backgrounds' });
    }
  });

  app.post('/api/quotes/generate', async (req, res) => {
    try {
      const { quoteId, backgroundId, fontStyle, textColor } = req.body;
      
      // Generate image and get its URL
      const imageUrl = await quotes.generateQuoteImage(quoteId, backgroundId, fontStyle, textColor);
      
      // Create GeneratedImage record
      const generatedImage = await storage.addGeneratedImage({
        quoteId,
        backgroundId,
        fontStyle,
        textColor,
        imageUrl
      });
      
      res.json(generatedImage);
    } catch (error) {
      console.error('Error generating quote image:', error);
      res.status(500).json({ error: 'Failed to generate quote image' });
    }
  });

  app.post('/api/posts/schedule', async (req, res) => {
    try {
      const { imageId, platform, caption, affiliateLink, scheduleDate } = req.body;
      
      const scheduledPost = await storage.addScheduledPost({
        imageId,
        platform,
        caption,
        affiliateLink,
        scheduleDate: new Date(scheduleDate)
      });
      
      res.json(scheduledPost);
    } catch (error) {
      console.error('Error scheduling post:', error);
      res.status(500).json({ error: 'Failed to schedule post' });
    }
  });
  
  // Social media posting endpoint
  app.post('/api/posts/share', async (req, res) => {
    try {
      const { platform, imageUrl, caption, affiliateLink } = req.body;
      
      if (!platform || !imageUrl || !caption) {
        return res.status(400).json({ error: 'Missing required fields: platform, imageUrl, caption' });
      }
      
      // Validate platform
      if (!['instagram', 'twitter', 'pinterest'].includes(platform)) {
        return res.status(400).json({ error: 'Invalid platform. Supported platforms: instagram, twitter, pinterest' });
      }
      
      // Post to social media
      const result = await socialMedia.postToSocialMedia({
        platform,
        imageUrl,
        caption,
        affiliateLink
      });
      
      if (result.success) {
        res.json({ success: true, message: result.message, postId: result.postId });
      } else {
        res.status(500).json({ success: false, error: result.message });
      }
    } catch (error) {
      console.error('Error sharing post to social media:', error);
      res.status(500).json({ error: 'Failed to share post to social media' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
