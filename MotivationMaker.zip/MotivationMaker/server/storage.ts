import { 
  quotes, 
  backgrounds, 
  generatedImages, 
  scheduledPosts,
  type Quote, 
  type InsertQuote, 
  type Background, 
  type InsertBackground, 
  type GeneratedImage, 
  type InsertGeneratedImage, 
  type ScheduledPost, 
  type InsertScheduledPost 
} from "@shared/schema";

export interface IStorage {
  // Quotes
  getQuote(id: number): Promise<Quote | undefined>;
  getRandomQuote(): Promise<Quote>;
  addQuote(quote: InsertQuote): Promise<Quote>;

  // Backgrounds
  getBackground(id: number): Promise<Background | undefined>;
  getBackgroundsByType(type: string): Promise<Background[]>;
  addBackground(background: InsertBackground): Promise<Background>;

  // Generated Images
  getGeneratedImage(id: number): Promise<GeneratedImage | undefined>;
  addGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;

  // Scheduled Posts
  getScheduledPost(id: number): Promise<ScheduledPost | undefined>;
  addScheduledPost(post: InsertScheduledPost): Promise<ScheduledPost>;
}

import { db } from "./db";
import { eq, sql } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  // Quotes
  async getQuote(id: number): Promise<Quote | undefined> {
    const [quote] = await db.select().from(quotes).where(eq(quotes.id, id));
    return quote;
  }

  async getRandomQuote(): Promise<Quote> {
    // Get a random quote using SQL random() function
    const [quote] = await db.select().from(quotes).orderBy(sql`RANDOM()`).limit(1);
    
    if (!quote) {
      throw new Error("No quotes available");
    }
    
    return quote;
  }

  async addQuote(quote: InsertQuote): Promise<Quote> {
    const [newQuote] = await db.insert(quotes)
      .values({
        text: quote.text,
        author: quote.author,
        category: quote.category || null
      })
      .returning();
      
    return newQuote;
  }

  // Backgrounds
  async getBackground(id: number): Promise<Background | undefined> {
    const [background] = await db.select().from(backgrounds).where(eq(backgrounds.id, id));
    return background;
  }

  async getBackgroundsByType(type: string): Promise<Background[]> {
    return await db.select().from(backgrounds).where(eq(backgrounds.type, type));
  }

  async addBackground(background: InsertBackground): Promise<Background> {
    const [newBackground] = await db.insert(backgrounds)
      .values({
        url: background.url,
        type: background.type,
        description: background.description || null
      })
      .returning();
      
    return newBackground;
  }

  // Generated Images
  async getGeneratedImage(id: number): Promise<GeneratedImage | undefined> {
    const [image] = await db.select().from(generatedImages).where(eq(generatedImages.id, id));
    return image;
  }

  async addGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage> {
    const [newImage] = await db.insert(generatedImages)
      .values({
        quoteId: image.quoteId,
        backgroundId: image.backgroundId,
        fontStyle: image.fontStyle,
        textColor: image.textColor,
        imageUrl: image.imageUrl || null,
        createdAt: new Date()
      })
      .returning();
      
    return newImage;
  }

  // Scheduled Posts
  async getScheduledPost(id: number): Promise<ScheduledPost | undefined> {
    const [post] = await db.select().from(scheduledPosts).where(eq(scheduledPosts.id, id));
    return post;
  }

  async addScheduledPost(post: InsertScheduledPost): Promise<ScheduledPost> {
    const [newPost] = await db.insert(scheduledPosts)
      .values({
        imageId: post.imageId,
        platform: post.platform,
        caption: post.caption,
        affiliateLink: post.affiliateLink || null,
        scheduleDate: post.scheduleDate,
        status: "pending",
        createdAt: new Date()
      })
      .returning();
      
    return newPost;
  }
}

export const storage = new DatabaseStorage();
