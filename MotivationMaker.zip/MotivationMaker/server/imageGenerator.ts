import { storage } from "./storage";

// Client-side image generation approach
class QuoteImageGenerator {
  constructor() {
    // Initialization is now done client-side
    console.log("Image generation is handled client-side");
  }

  async generateQuoteImage(
    quoteId: number,
    backgroundId: number,
    fontStyle: string,
    textColor: string
  ): Promise<string> {
    try {
      // Get quote and background from storage
      const quote = await storage.getQuote(quoteId);
      const background = await storage.getBackground(backgroundId);

      if (!quote || !background) {
        throw new Error("Quote or background not found");
      }

      // Instead of generating on server, we return the data needed for client-side generation
      return JSON.stringify({
        quoteId,
        backgroundId,
        quoteText: quote.text,
        author: quote.author,
        backgroundUrl: background.url,
        fontStyle,
        textColor,
        timestamp: Date.now()
      });
    } catch (error) {
      console.error("Error preparing quote data:", error);
      throw error;
    }
  }
}

export const quotes = new QuoteImageGenerator();
