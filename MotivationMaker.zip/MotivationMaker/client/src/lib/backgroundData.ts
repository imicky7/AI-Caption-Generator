export const backgroundImages = {
  landscape: [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3",
      description: "Mountain landscape with fog in the valley"
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?ixlib=rb-4.0.3",
      description: "Sunset over calm ocean waters"
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3",
      description: "Serene forest with sunlight through trees"
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?ixlib=rb-4.0.3",
      description: "Misty mountain landscape"
    },
    {
      id: 5,
      url: "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?ixlib=rb-4.0.3",
      description: "Beach landscape with waves"
    },
    {
      id: 6,
      url: "https://images.unsplash.com/photo-1498429089284-41f8cf3ffd39?ixlib=rb-4.0.3",
      description: "Mountain peaks above clouds"
    }
  ],
  nature: [
    {
      id: 7,
      url: "https://images.unsplash.com/photo-1502082553048-f009c37129b9?ixlib=rb-4.0.3",
      description: "Green leaves in forest"
    },
    {
      id: 8,
      url: "https://images.unsplash.com/photo-1477414348463-c0eb7f1359b6?ixlib=rb-4.0.3",
      description: "Autumn forest with fallen leaves"
    },
    {
      id: 9,
      url: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?ixlib=rb-4.0.3",
      description: "Close-up of water drops on leaf"
    },
    {
      id: 10,
      url: "https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?ixlib=rb-4.0.3",
      description: "Purple wildflowers"
    },
    {
      id: 11,
      url: "https://images.unsplash.com/photo-1470770903676-69b98201ea1c?ixlib=rb-4.0.3",
      description: "Field of golden grass"
    },
    {
      id: 12,
      url: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?ixlib=rb-4.0.3",
      description: "Northern lights over mountains"
    }
  ],
  abstract: [
    {
      id: 13,
      url: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?ixlib=rb-4.0.3",
      description: "Abstract gradient background"
    },
    {
      id: 14,
      url: "https://images.unsplash.com/photo-1604871000636-074fa5117945?ixlib=rb-4.0.3",
      description: "Colorful paint swirls"
    },
    {
      id: 15,
      url: "https://images.unsplash.com/photo-1553356084-58ef4a67b2a7?ixlib=rb-4.0.3",
      description: "Blue and purple smoke"
    },
    {
      id: 16,
      url: "https://images.unsplash.com/photo-1599689019338-50deb475f380?ixlib=rb-4.0.3",
      description: "Abstract liquid art"
    },
    {
      id: 17,
      url: "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?ixlib=rb-4.0.3",
      description: "Colorful gradient mesh"
    },
    {
      id: 18,
      url: "https://images.unsplash.com/photo-1567359781514-3b964e2b04d6?ixlib=rb-4.0.3",
      description: "Abstract mountain artwork"
    }
  ]
};
