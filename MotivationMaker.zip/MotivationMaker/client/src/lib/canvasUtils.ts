import { FontStyle } from "@/pages/Home";
import { getFontSettings, wrapText } from "./quoteUtils";

export function drawQuoteOnCanvas(
  canvas: HTMLCanvasElement,
  backgroundImage: HTMLImageElement,
  quoteText: string,
  authorName: string,
  fontStyle: FontStyle,
  textColor: string
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Canvas dimensions
  const canvasWidth = canvas.width;
  const canvasHeight = canvas.height;

  // Clear canvas
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  // Draw background
  ctx.drawImage(backgroundImage, 0, 0, canvasWidth, canvasHeight);

  // Add gradient overlay
  const gradient = ctx.createLinearGradient(0, 0, 0, canvasHeight);
  gradient.addColorStop(0, 'rgba(0, 0, 0, 0.4)');
  gradient.addColorStop(1, 'rgba(0, 0, 0, 0.4)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);

  // Set font settings based on style
  const fontSettings = getFontSettings(fontStyle);
  
  // Format quote with quotation marks
  const formattedQuote = `"${quoteText}"`;

  // Draw quote text
  ctx.textAlign = 'center';
  ctx.fillStyle = textColor;
  
  // Quote text
  ctx.font = `${fontSettings.fontStyle} ${fontSettings.fontWeight} 60px ${fontSettings.fontFamily}`;
  const maxWidth = canvasWidth * 0.8;
  const lineHeight = 78;
  const startY = canvasHeight / 2 - 100;
  
  const endY = wrapText(ctx, formattedQuote, canvasWidth / 2, startY, maxWidth, lineHeight);
  
  // Author name
  ctx.font = `normal 400 40px ${fontSettings.fontFamily}`;
  ctx.fillText(`- ${authorName}`, canvasWidth / 2, endY + 60);
}

export function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(blob);
      } else {
        reject(new Error('Failed to convert canvas to blob'));
      }
    }, 'image/png');
  });
}
