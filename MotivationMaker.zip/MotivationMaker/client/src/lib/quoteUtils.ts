import { FontStyle } from "@/pages/Home";

export function getFontSettings(fontStyle: FontStyle): {
  fontFamily: string;
  fontWeight: string;
  fontStyle: string;
} {
  switch (fontStyle) {
    case "elegant":
      return {
        fontFamily: "Playfair Display, serif",
        fontWeight: "500",
        fontStyle: "italic",
      };
    case "modern":
      return {
        fontFamily: "Inter, sans-serif",
        fontWeight: "600",
        fontStyle: "normal",
      };
    case "classic":
      return {
        fontFamily: "Georgia, serif",
        fontWeight: "400",
        fontStyle: "normal",
      };
    default:
      return {
        fontFamily: "Playfair Display, serif",
        fontWeight: "500",
        fontStyle: "italic",
      };
  }
}

export function formatQuoteText(text: string, maxWidth: number, context: CanvasRenderingContext2D): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = '';

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const width = context.measureText(currentLine + ' ' + word).width;
    
    if (width < maxWidth) {
      currentLine += (currentLine ? ' ' : '') + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  
  if (currentLine) {
    lines.push(currentLine);
  }
  
  return lines;
}

export function wrapText(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number
): number {
  const lines = formatQuoteText(text, maxWidth, context);
  
  for (let i = 0; i < lines.length; i++) {
    context.fillText(lines[i], x, y + i * lineHeight);
  }
  
  return y + lines.length * lineHeight;
}
