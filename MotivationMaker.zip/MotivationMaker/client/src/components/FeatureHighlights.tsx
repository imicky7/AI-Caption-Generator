import { FaMagic, FaDownload, FaDollarSign } from "react-icons/fa";

export default function FeatureHighlights() {
  return (
    <div className="mt-12 bg-white dark:bg-gray-800 rounded-xl shadow-md p-8">
      <h3 className="text-2xl font-semibold text-center mb-8 text-dark dark:text-white">How AutoQuotes Works</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="text-center">
          <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4">
            <FaMagic className="text-primary text-2xl" />
          </div>
          <h4 className="text-lg font-semibold mb-2 dark:text-white">1. Generate</h4>
          <p className="text-gray-600 dark:text-gray-300">Create beautiful quote images with just a few clicks. Choose from various backgrounds and styles.</p>
        </div>
        
        <div className="text-center">
          <div className="bg-green-100 dark:bg-green-900 w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4">
            <FaDownload className="text-secondary text-2xl" />
          </div>
          <h4 className="text-lg font-semibold mb-2 dark:text-white">2. Download or Schedule</h4>
          <p className="text-gray-600 dark:text-gray-300">Save your images locally or schedule them for automatic posting on your social platforms.</p>
        </div>
        
        <div className="text-center">
          <div className="bg-yellow-100 dark:bg-yellow-900 w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4">
            <FaDollarSign className="text-accent text-2xl" />
          </div>
          <h4 className="text-lg font-semibold mb-2 dark:text-white">3. Earn</h4>
          <p className="text-gray-600 dark:text-gray-300">Include affiliate links in your captions to generate passive income while inspiring others.</p>
        </div>
      </div>
    </div>
  );
}
