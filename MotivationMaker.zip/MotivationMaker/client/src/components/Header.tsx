import { FaQuoteLeft, FaMoon, FaSun } from "react-icons/fa";
import { useTheme } from "@/lib/ThemeProvider";
import { Button } from "@/components/ui/button";

export default function Header() {
  const { theme, setTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <FaQuoteLeft className="text-primary text-2xl" />
          <h1 className="text-2xl font-bold text-dark dark:text-white">AutoQuotes</h1>
        </div>
        <nav>
          <Button
            id="theme-toggle"
            variant="ghost"
            size="icon"
            className="rounded-full"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <FaSun className="text-yellow-400 text-lg" />
            ) : (
              <FaMoon className="text-gray-600 text-lg" />
            )}
          </Button>
        </nav>
      </div>
    </header>
  );
}
