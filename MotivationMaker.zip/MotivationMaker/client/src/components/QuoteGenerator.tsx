import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useEffect, useState, useRef } from "react";
import { BackgroundType, FontStyle, QuoteImageSettings, QuoteSource } from "@/pages/Home";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { FaCloudUploadAlt, FaMagic } from "react-icons/fa";

interface QuoteGeneratorProps {
  settings: QuoteImageSettings;
  onUpdateSettings: (settings: QuoteImageSettings) => void;
  onGenerateQuote: () => void;
  isGenerating: boolean;
}

export default function QuoteGenerator({
  settings,
  onUpdateSettings,
  onGenerateQuote,
  isGenerating
}: QuoteGeneratorProps) {
  const [backgroundThumbnails, setBackgroundThumbnails] = useState<string[]>([]);
  const [customImage, setCustomImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: backgrounds } = useQuery({
    queryKey: [`/api/backgrounds/${settings.backgroundType}`],
    enabled: settings.backgroundType !== 'custom',
  });

  useEffect(() => {
    if (backgrounds && Array.isArray(backgrounds) && backgrounds.length > 0) {
      setBackgroundThumbnails(backgrounds.slice(0, 3).map((bg: any) => bg.url));
    }
  }, [backgrounds, settings.backgroundType]);
  
  // Random caption generator
  const generateRandomCaption = () => {
    const captions = [
      "When life gives you lemons, make lemonade.",
      "The journey of a thousand miles begins with a single step.",
      "Success is not final, failure is not fatal: It is the courage to continue that counts.",
      "Believe you can and you're halfway there.",
      "Your time is limited, don't waste it living someone else's life.",
      "The only way to do great work is to love what you do.",
      "It always seems impossible until it's done.",
      "Don't count the days, make the days count.",
      "The best revenge is massive success.",
      "Be the change that you wish to see in the world."
    ];
    
    const authors = [
      "Unknown",
      "Lao Tzu",
      "Winston Churchill",
      "Theodore Roosevelt",
      "Steve Jobs",
      "Maya Angelou",
      "Nelson Mandela",
      "Muhammad Ali",
      "Frank Sinatra",
      "Mahatma Gandhi"
    ];
    
    const randomCaptionIndex = Math.floor(Math.random() * captions.length);
    const randomAuthorIndex = Math.floor(Math.random() * authors.length);
    
    onUpdateSettings({
      ...settings,
      quoteSource: "custom",
      customQuote: captions[randomCaptionIndex],
      customAuthor: authors[randomAuthorIndex]
    });
    
    toast({
      title: "Random Caption Generated",
      description: "A new inspirational caption has been created for your image."
    });
  };

  const handleBgTypeChange = (type: BackgroundType) => {
    onUpdateSettings({ ...settings, backgroundType: type });
    
    // Open file dialog when custom is selected
    if (type === 'custom' && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // Handle file upload for custom background
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Check if file is an image
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPG, PNG, etc.)",
        variant: "destructive"
      });
      return;
    }
    
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image smaller than 5MB",
        variant: "destructive"
      });
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setCustomImage(imageUrl);
      onUpdateSettings({ 
        ...settings, 
        backgroundType: 'custom',
        backgroundUrl: imageUrl
      });
    };
    reader.readAsDataURL(file);
  };

  const handleQuoteSourceChange = (source: QuoteSource) => {
    onUpdateSettings({ ...settings, quoteSource: source });
  };

  const handleFontStyleChange = (style: FontStyle) => {
    onUpdateSettings({ ...settings, fontStyle: style });
  };

  const handleTextColorChange = (color: string) => {
    onUpdateSettings({ ...settings, textColor: color });
  };

  const handleCustomQuoteChange = (value: string) => {
    onUpdateSettings({ ...settings, customQuote: value });
  };

  const handleCustomAuthorChange = (value: string) => {
    onUpdateSettings({ ...settings, customAuthor: value });
  };

  const handleBackgroundSelect = (url: string) => {
    onUpdateSettings({ ...settings, backgroundUrl: url });
  };

  return (
    <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 h-fit order-2 lg:order-1">
      <h3 className="text-xl font-semibold mb-4 text-dark dark:text-white">Customize Your Quote</h3>
      
      {/* Controls Section */}
      <div className="space-y-4">
        {/* Background Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Background Type</label>
          <div className="grid grid-cols-4 gap-2 mb-4">
            <Button 
              variant={settings.backgroundType === "landscape" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleBgTypeChange("landscape")}
            >
              Landscape
            </Button>
            <Button 
              variant={settings.backgroundType === "nature" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleBgTypeChange("nature")}
            >
              Nature
            </Button>
            <Button 
              variant={settings.backgroundType === "abstract" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleBgTypeChange("abstract")}
            >
              Abstract
            </Button>
            <Button 
              variant={settings.backgroundType === "custom" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleBgTypeChange("custom")}
            >
              Upload
            </Button>
          </div>
          
          {/* Visual Background Options */}
          {settings.backgroundType !== 'custom' ? (
            <div className="grid grid-cols-3 gap-2">
              {backgroundThumbnails.map((url, index) => (
                <div 
                  key={index}
                  className={`h-16 bg-cover bg-center rounded-lg cursor-pointer ${settings.backgroundUrl === url ? 'border-2 border-primary' : 'border border-gray-200'}`}
                  style={{ backgroundImage: `url('${url}?auto=format&fit=crop&w=100&h=100')` }}
                  onClick={() => handleBackgroundSelect(url)}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-3">
              {/* Hidden file input */}
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                className="hidden" 
                onChange={handleFileUpload}
              />
              
              {/* Custom image preview or upload button */}
              {customImage ? (
                <div className="space-y-2">
                  <div 
                    className="h-24 bg-cover bg-center rounded-lg border-2 border-primary"
                    style={{ backgroundImage: `url('${customImage}')` }}
                  ></div>
                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <FaCloudUploadAlt className="mr-1" /> Change Image
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      className="text-xs"
                      onClick={generateRandomCaption}
                    >
                      <FaMagic className="mr-1" /> Random Caption
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  variant="outline"
                  className="w-full h-24 flex flex-col items-center justify-center border-dashed border-2"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <FaCloudUploadAlt className="text-2xl mb-2 text-gray-400" />
                  <span className="text-sm text-gray-500">Click to upload image</span>
                  <span className="text-xs text-gray-400 mt-1">JPG, PNG, GIF up to 5MB</span>
                </Button>
              )}
            </div>
          )}
        </div>
        
        {/* Quote Control */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Quote Source</label>
          <div className="grid grid-cols-3 gap-2 mb-4">
            <Button 
              variant={settings.quoteSource === "random" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleQuoteSourceChange("random")}
            >
              Random
            </Button>
            <Button 
              variant={settings.quoteSource === "custom" ? "default" : "outline"}
              className="text-sm h-9"
              onClick={() => handleQuoteSourceChange("custom")}
            >
              Custom
            </Button>
            <Button 
              variant="outline"
              className="text-sm h-9 bg-accent text-white hover:bg-amber-600"
              onClick={generateRandomCaption}
            >
              <FaMagic className="mr-1" />
              Caption
            </Button>
          </div>
          
          {settings.quoteSource === "custom" && (
            <div>
              <Textarea 
                placeholder="Enter your custom quote here..." 
                value={settings.customQuote}
                onChange={(e) => handleCustomQuoteChange(e.target.value)}
                className="w-full mb-2"
                rows={3}
              />
              <Input 
                type="text" 
                placeholder="Author (optional)" 
                value={settings.customAuthor}
                onChange={(e) => handleCustomAuthorChange(e.target.value)}
                className="w-full"
              />
            </div>
          )}
        </div>
        
        {/* Font Styling */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Font Style</label>
          <div className="grid grid-cols-3 gap-2">
            <Button 
              variant={settings.fontStyle === "elegant" ? "default" : "outline"}
              className="text-sm h-9 font-quote"
              onClick={() => handleFontStyleChange("elegant")}
            >
              Elegant
            </Button>
            <Button 
              variant={settings.fontStyle === "modern" ? "default" : "outline"}
              className="text-sm h-9 font-sans"
              onClick={() => handleFontStyleChange("modern")}
            >
              Modern
            </Button>
            <Button 
              variant={settings.fontStyle === "classic" ? "default" : "outline"}
              className="text-sm h-9 font-mono"
              onClick={() => handleFontStyleChange("classic")}
            >
              Classic
            </Button>
          </div>
        </div>
        
        {/* Text Color */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Text Color</label>
          <div className="flex space-x-2">
            {["#FFFFFF", "#FEF9C3", "#DBEAFE", "#FCE7F3", "#1F2937"].map((color) => (
              <button
                key={color}
                className={`w-8 h-8 rounded-full border ${settings.textColor === color ? 'border-primary border-2' : 'border-gray-300'}`}
                style={{ backgroundColor: color }}
                onClick={() => handleTextColorChange(color)}
                aria-label={`Select text color ${color}`}
              />
            ))}
          </div>
        </div>
        
        {/* Generate Button */}
        <Button 
          className="w-full py-3 px-4"
          onClick={onGenerateQuote}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>Generating...</span>
            </>
          ) : (
            <>
              <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              <span>Generate New Quote</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
