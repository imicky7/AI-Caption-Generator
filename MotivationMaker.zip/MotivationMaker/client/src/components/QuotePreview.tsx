import { Button } from "@/components/ui/button";
import { QuoteImageSettings } from "@/pages/Home";
import { FaDownload, FaCalendarAlt } from "react-icons/fa";
import { useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { canvasToBlob, drawQuoteOnCanvas } from "@/lib/canvasUtils";
import * as htmlToImage from 'html-to-image';

interface QuotePreviewProps {
  settings: QuoteImageSettings;
  quote: {
    text: string;
    author: string;
  };
  onGenerateQuote: () => void;
  isGenerating: boolean;
}

export default function QuotePreview({ 
  settings, 
  quote,
  onGenerateQuote,
  isGenerating
}: QuotePreviewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  
  // Determine which quote to display
  const displayQuote = settings.quoteSource === "custom" && settings.customQuote 
    ? { 
        text: settings.customQuote, 
        author: settings.customAuthor || "Unknown" 
      }
    : quote;

  useEffect(() => {
    const loadImage = async () => {
      if (!canvasRef.current) return;
      
      try {
        const canvas = canvasRef.current;
        const image = new Image();
        image.crossOrigin = "anonymous";
        
        image.onload = () => {
          drawQuoteOnCanvas(
            canvas, 
            image, 
            displayQuote.text, 
            displayQuote.author, 
            settings.fontStyle, 
            settings.textColor
          );
        };
        
        // Add a cache-busting parameter
        image.src = settings.backgroundUrl + (settings.backgroundUrl.includes('?') ? '&' : '?') + 'auto=format&w=1080&h=1350&q=80&_=' + Date.now();
      } catch (error) {
        console.error("Error loading image:", error);
      }
    };
    
    loadImage();
  }, [settings, displayQuote]);

  const handleDownload = async () => {
    const quoteElement = document.getElementById('quote-preview');
    if (!quoteElement) return;
    
    try {
      const dataUrl = await htmlToImage.toPng(quoteElement, {
        quality: 0.95,
        pixelRatio: 2
      });
      
      const link = document.createElement('a');
      link.download = 'autoquote.png';
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success!",
        description: "Your quote image has been downloaded.",
      });
    } catch (error) {
      console.error("Error downloading image:", error);
      toast({
        title: "Download failed",
        description: "There was a problem downloading your image. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const scrollToScheduling = () => {
    document.getElementById('scheduling-panel')?.scrollIntoView({ 
      behavior: 'smooth' 
    });
  };

  return (
    <div className="lg:col-span-1 flex flex-col items-center order-1 lg:order-2">
      {/* Quote Preview Container */}
      <div className="w-full max-w-sm mx-auto mb-4">
        <div 
          id="quote-preview"
          className="quote-container relative rounded-xl overflow-hidden shadow-lg flex items-center justify-center"
          style={{
            backgroundImage: `url(${settings.backgroundUrl})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            position: 'relative'
          }}
        >
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-overlay"></div>
          
          {/* Quote content */}
          <div className="relative z-10 text-center p-8">
            <p 
              className={`text-2xl md:text-3xl mb-4 ${settings.fontStyle === 'elegant' ? 'font-quote italic' : 
                settings.fontStyle === 'modern' ? 'font-sans font-semibold' : 'font-mono'}`}
              style={{ color: settings.textColor }}
            >
              "{displayQuote.text}"
            </p>
            <p 
              className={`text-lg md:text-xl ${settings.fontStyle === 'elegant' ? 'font-quote' : 
                settings.fontStyle === 'modern' ? 'font-sans' : 'font-mono'}`}
              style={{ color: settings.textColor }}
            >
              - {displayQuote.author}
            </p>
          </div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="flex space-x-3 mb-6">
        <Button
          variant="outline"
          className="font-medium"
          onClick={handleDownload}
          disabled={isGenerating}
        >
          <FaDownload className="mr-2 text-gray-600" />
          <span>Download</span>
        </Button>
        <Button
          variant="secondary"
          className="font-medium"
          onClick={scrollToScheduling}
          disabled={isGenerating}
        >
          <FaCalendarAlt className="mr-2" />
          <span>Schedule Post</span>
        </Button>
      </div>
      
      {/* Image Dimensions */}
      <div className="text-sm text-gray-500 mb-6">
        <span>Image dimensions: 1080 × 1350px (Instagram optimal)</span>
      </div>
    </div>
  );
}
