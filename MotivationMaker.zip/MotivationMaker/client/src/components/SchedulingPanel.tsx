import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Platform, ScheduleSettings } from "@/pages/Home";
import { FaInstagram, FaPinterest, FaTwitter, FaPaperPlane, FaLink } from "react-icons/fa";
import { useToast } from "@/hooks/use-toast";

interface SchedulingPanelProps {
  settings: ScheduleSettings;
  onUpdateSettings: (settings: ScheduleSettings) => void;
  quote: {
    text: string;
    author: string;
  };
}

export default function SchedulingPanel({ 
  settings, 
  onUpdateSettings,
  quote
}: SchedulingPanelProps) {
  const { toast } = useToast();

  const handlePlatformSelect = (platform: Platform) => {
    onUpdateSettings({ ...settings, platform });
  };

  const handleCaptionChange = (caption: string) => {
    onUpdateSettings({ ...settings, caption });
  };

  const handleAffiliateCategoryChange = (affiliateCategory: string) => {
    onUpdateSettings({ ...settings, affiliateCategory });
  };

  const handleDateChange = (postDate: string) => {
    onUpdateSettings({ ...settings, postDate });
  };

  const handleTimeChange = (postTime: string) => {
    onUpdateSettings({ ...settings, postTime });
  };

  const insertAffiliateLink = () => {
    // Map categories to mock affiliate links
    const affiliateLinks: Record<string, string> = {
      "Self-Help Books": "https://amzn.to/self-help-bestseller",
      "Productivity Tools": "https://amzn.to/productivity-planner",
      "Motivational Courses": "https://course-link.com/motivation101",
      "Wellness Products": "https://amzn.to/meditation-kit"
    };

    const link = affiliateLinks[settings.affiliateCategory] || "https://amzn.to/affiliate-link";
    const updatedCaption = settings.caption.includes('https://') 
      ? settings.caption.replace(/https:\/\/[^\s]+/, link)
      : `${settings.caption}\n\nCheck out: ${link}`;
    
    handleCaptionChange(updatedCaption);
    
    toast({
      title: "Affiliate Link Added",
      description: `Added ${settings.affiliateCategory} affiliate link to your caption.`,
    });
  };

  const handleSchedulePost = () => {
    toast({
      title: "Post Scheduled!",
      description: `Your quote will be posted to ${settings.platform} on ${settings.postDate} at ${settings.postTime}.`,
    });
  };

  const connectService = (service: 'zapier' | 'buffer') => {
    toast({
      title: `Connect to ${service}`,
      description: `This would connect to ${service} in a complete implementation.`,
    });
  };

  return (
    <div className="lg:col-span-1 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 order-3 h-fit" id="scheduling-panel">
      <h3 className="text-xl font-semibold mb-4 text-dark dark:text-white">Schedule for Social Media</h3>
      
      {/* Platform Selection */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Platform</label>
        <div className="grid grid-cols-3 gap-2">
          <Button
            type="button"
            className={`py-2 px-3 rounded-lg text-sm flex items-center justify-center ${
              settings.platform === "instagram" 
                ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white" 
                : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
            }`}
            onClick={() => handlePlatformSelect("instagram")}
          >
            <FaInstagram className="mr-1" /> Instagram
          </Button>
          <Button
            type="button"
            className={`py-2 px-3 rounded-lg text-sm flex items-center justify-center ${
              settings.platform === "pinterest" 
                ? "bg-red-600 text-white" 
                : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
            }`}
            onClick={() => handlePlatformSelect("pinterest")}
          >
            <FaPinterest className="mr-1" /> Pinterest
          </Button>
          <Button
            type="button"
            className={`py-2 px-3 rounded-lg text-sm flex items-center justify-center ${
              settings.platform === "twitter" 
                ? "bg-blue-400 text-white" 
                : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
            }`}
            onClick={() => handlePlatformSelect("twitter")}
          >
            <FaTwitter className="mr-1" /> Twitter
          </Button>
        </div>
      </div>
      
      {/* Caption Editor */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Caption</label>
        <Textarea
          value={settings.caption}
          onChange={(e) => handleCaptionChange(e.target.value)}
          className="w-full p-3"
          rows={3}
        />
      </div>
      
      {/* Affiliate Link */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Add Affiliate Product</label>
        <div className="flex space-x-2">
          <Select 
            value={settings.affiliateCategory}
            onValueChange={handleAffiliateCategoryChange}
          >
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Self-Help Books">Self-Help Books</SelectItem>
              <SelectItem value="Productivity Tools">Productivity Tools</SelectItem>
              <SelectItem value="Motivational Courses">Motivational Courses</SelectItem>
              <SelectItem value="Wellness Products">Wellness Products</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="default"
            className="bg-accent hover:bg-yellow-600"
            onClick={insertAffiliateLink}
          >
            <FaLink />
          </Button>
        </div>
      </div>
      
      {/* Scheduling Options */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">When to Post</label>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">Date</label>
            <Input
              type="date"
              value={settings.postDate}
              onChange={(e) => handleDateChange(e.target.value)}
              className="w-full p-2"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">Time</label>
            <Input
              type="time"
              value={settings.postTime}
              onChange={(e) => handleTimeChange(e.target.value)}
              className="w-full p-2"
            />
          </div>
        </div>
      </div>
      
      {/* Service Connection */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Connect With</label>
        <div className="grid grid-cols-2 gap-2">
          <Button 
            type="button"
            className="bg-purple-600 hover:bg-purple-700 text-white py-2 px-3 rounded-lg text-sm flex items-center justify-center"
            onClick={() => connectService('zapier')}
          >
            <img src="https://cdn.zapier.com/zapier/images/favicon.ico" alt="Zapier" className="w-4 h-4 mr-2" />
            Zapier
          </Button>
          <Button 
            type="button"
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-3 rounded-lg text-sm flex items-center justify-center"
            onClick={() => connectService('buffer')}
          >
            <img src="https://buffer.com/favicon.ico" alt="Buffer" className="w-4 h-4 mr-2" />
            Buffer
          </Button>
        </div>
      </div>
      
      {/* Schedule Button */}
      <Button 
        className="w-full bg-secondary hover:bg-green-600 text-white font-medium py-3 px-4"
        onClick={handleSchedulePost}
      >
        <FaPaperPlane className="mr-2" />
        Schedule Post
      </Button>
      
      {/* Integration Info */}
      <div className="mt-4 text-xs text-gray-500 dark:text-gray-400 italic">
        <p>Posts will be sent to your connected service for scheduling</p>
      </div>
    </div>
  );
}
