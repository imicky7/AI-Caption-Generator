import QuoteGenerator from "@/components/QuoteGenerator";
import QuotePreview from "@/components/QuotePreview";
import SchedulingPanel from "@/components/SchedulingPanel";
import FeatureHighlights from "@/components/FeatureHighlights";
import { useState } from "react";

export type FontStyle = "elegant" | "modern" | "classic";
export type BackgroundType = "landscape" | "nature" | "abstract" | "custom";
export type QuoteSource = "random" | "custom";
export type Platform = "instagram" | "pinterest" | "twitter";

export interface QuoteImageSettings {
  backgroundType: BackgroundType;
  backgroundUrl: string;
  quoteSource: QuoteSource;
  customQuote: string;
  customAuthor: string;
  fontStyle: FontStyle;
  textColor: string;
}

export interface ScheduleSettings {
  platform: Platform;
  caption: string;
  affiliateCategory: string; 
  postDate: string;
  postTime: string;
}

export default function Home() {
  const [quoteSettings, setQuoteSettings] = useState<QuoteImageSettings>({
    backgroundType: "landscape",
    backgroundUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3",
    quoteSource: "random",
    customQuote: "",
    customAuthor: "",
    fontStyle: "elegant",
    textColor: "#FFFFFF"
  });

  const [currentQuote, setCurrentQuote] = useState<{
    text: string;
    author: string;
  }>({
    text: "The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle.",
    author: "Steve Jobs"
  });

  const [scheduleSettings, setScheduleSettings] = useState<ScheduleSettings>({
    platform: "instagram",
    caption: `✨ Daily inspiration to keep you motivated!\n\n"${currentQuote.text}"\n\n#motivation #success #inspiration\n\nCheck out this amazing self-help book: https://amzn.to/abc123`,
    affiliateCategory: "Self-Help Books",
    postDate: new Date().toISOString().slice(0, 10),
    postTime: "08:30"
  });

  const [isGenerating, setIsGenerating] = useState(false);
  
  const handleGenerateQuote = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/quotes/random');
      if (!response.ok) throw new Error('Failed to fetch quote');
      
      const data = await response.json();
      setCurrentQuote({
        text: data.text,
        author: data.author
      });
      
      // Update caption with new quote
      setScheduleSettings(prev => ({
        ...prev,
        caption: `✨ Daily inspiration to keep you motivated!\n\n"${data.text}"\n\n#motivation #success #inspiration\n\nCheck out this amazing self-help book: https://amzn.to/abc123`
      }));

      // Also update background if not using custom quote
      if (quoteSettings.quoteSource === "random") {
        const bgResponse = await fetch(`/api/backgrounds/${quoteSettings.backgroundType}`);
        if (!bgResponse.ok) throw new Error('Failed to fetch background');
        
        const bgData = await bgResponse.json();
        setQuoteSettings(prev => ({
          ...prev,
          backgroundUrl: bgData.url
        }));
      }
    } catch (error) {
      console.error("Error generating quote:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <main className="container mx-auto px-4 py-8 md:py-12">
      {/* App Introduction */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-dark mb-3">Create & Schedule Inspirational Quotes</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">Generate beautiful quote images, download them, or schedule for auto-posting on your social media with affiliate links - all in one place.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <QuoteGenerator 
          settings={quoteSettings}
          onUpdateSettings={setQuoteSettings}
          onGenerateQuote={handleGenerateQuote}
          isGenerating={isGenerating}
        />
        
        <QuotePreview 
          settings={quoteSettings}
          quote={currentQuote}
          onGenerateQuote={handleGenerateQuote}
          isGenerating={isGenerating}
        />
        
        <SchedulingPanel 
          settings={scheduleSettings}
          onUpdateSettings={setScheduleSettings}
          quote={currentQuote}
        />
      </div>

      <FeatureHighlights />
    </main>
  );
}
